module.exports = {
  'env': {
    'node': true,
    'jest': true
  }
}
